CMD에서 npm start 작동 후 패키지가 없다는 에러가 뜨면
 -> npm install [없는 패키지]
폴더에서 npm start 하면 작동 됨